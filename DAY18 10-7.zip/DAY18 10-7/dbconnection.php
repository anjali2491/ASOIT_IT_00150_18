<?php
echo "welcome to the stage where we are ready to get connected to a database";

$servername="localhost";
$username="root";
$password="";

$conn=mysqli_connect($servername,$username,$password);

if(!$conn){
    die("sorry we failed to connect:" . mysqli_connect_error());
}
else{
    echo "connection was successful!";
}
?>