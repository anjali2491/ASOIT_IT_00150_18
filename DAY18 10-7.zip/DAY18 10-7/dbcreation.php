<?php
echo "welcome to the stage where we are ready to get connected to a database";

$servername="localhost";
$username="root";
$password="";

$conn=mysqli_connect($servername,$username,$password);

if(!$conn){
    die("sorry we failed to connect:" . mysqli_connect_error());
}
else{
    echo "connection was successful!";
}

$sql="CREATE DATABASE dbSDP";
$result=mysqli_query($conn,$sql);

if($result){
    echo "the db was created succesfully!<br>";
}
else{
    echo "the db was not created succesfully because of this error ---->".mysqli_error($conn);
}
?>