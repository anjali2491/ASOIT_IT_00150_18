<?php
echo "welcome to the stage where we are ready to get connected to a database";

$servername="localhost";
$username="root";
$password="";
$database="dbSDP";

$conn=mysqli_connect($servername,$username,$password,$database);

if(!$conn){
    die("sorry we failed to connect:" . mysqli_connect_error());
}
else{
    echo "connection was successful!<br>";
}


$sql="CREATE TABLE `php`(`sno` INT(6) NOT NULL AUTO_INCREMENT , `name` VARCHAR(12) NOT NULL ,`dest` VARCHAR(6) NOT NULL,PRIMARY KEY (`sno`))";
$result=mysqli_query($conn,$sql);

if($result){
    echo "the table was created succesfully!<br>";
}
else{
    echo "the table was not created succesfully because of this error ----->".mysqli_error($conn);
}
?>
